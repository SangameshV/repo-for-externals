import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * This enum has the list of commands the are supported for users actions
 * 
 * @author SangameshVi
 *
 */
enum Commands {

	LIST("LIST"), DELETE("DEL"), INSERT("INS"), SAVE("SAVE"), QUIT("QUIT");

	/**
	 * 
	 */
	public final String label;

	private Commands(String label) {
		this.label = label;
	}

	/**
	 * @return the label of the enum
	 */
	public String getLabel() {
		return label;
	}

	@Override
	public String toString() {
		return this.label;
	}
}



/**
 * This class is responsible for executing the user commands on the file content
 * 
 * @author SangameshVi
 *
 */
class CommandsExecutor {

	private List<String> readFileInList;

	/**
	 * Constructor
	 * 
	 * @param fileData The input file data is read and stored to a list each line
	 *                 being each entry in it
	 */
	public CommandsExecutor(final List<String> fileData) {
		this.readFileInList = fileData;
	}

	/**
	 * This method takes care to execute the user command
	 */
	public void executeCommand() {
		String command = Constants.EMPTY;
		while (!command.equalsIgnoreCase(Commands.QUIT.label)) {
			command = new Scanner(System.in).nextLine();
			if (command.equalsIgnoreCase(Commands.LIST.label)) {
				String output = readInputFileContent();
				System.out.println(output);
				continue;
			} else if (command.equalsIgnoreCase(Commands.QUIT.label)) {
				System.out.println("Shutting down the application. Thank you!");
				System.exit(0);
			} else if (command.toUpperCase().startsWith(Commands.DELETE.label)) {
				String[] splits = command.split(Constants.SPACE);
				try {
					int rowNumber = Integer.parseInt(splits[1]);
					if (rowNumber > readFileInList.size() || rowNumber < 1) {
						System.out.println("Row " + rowNumber + " doesn't exist. Failed to delete.");
					} else {
						readFileInList.remove(rowNumber - 1);
						System.out.println("Deleted the row " + rowNumber);
					}
				} catch (NumberFormatException expt) {
					System.out.println("Row Number must be an interger number");
				}
				continue;
			} else if (command.toUpperCase().startsWith(Commands.INSERT.label)) {
				String[] splits = command.split(Constants.SPACE);
				int rowNumber = 0;
				String content = Constants.EMPTY;
				try {
					if (splits.length == Constants.DEF_INPUT_PARAMS_FOR_INSERT_CMD) {
						rowNumber = Integer.parseInt(splits[1]);
						content = Constants.EMPTY;
					} else if (splits.length >= Constants.INPUT_PARAMS_FOR_INSERT_CMD) {
						rowNumber = Integer.parseInt(splits[1]);
						content = command.replace(splits[0], Constants.EMPTY).replace(splits[1], Constants.EMPTY)
								.trim();
					} else {
						System.out.println(
								"Insert command must have a row number and/or content to insert (seperated by a space)");
						continue;
					}
				} catch (NumberFormatException expt) {
					System.out.println("Row Number must be an interger number");
				}

				if (rowNumber < 1) {
					System.out.println("Insert is not possible below Row#1.");
					continue;
				}

				int existingContentLines = readFileInList.size();
				/**
				 * If 0 < rowNumber > rows_in_file, add an element to the list and adjust the row numbers of subsequent rows<br>
				 * 
				 */
				if (rowNumber <= existingContentLines) {
					readFileInList.add(rowNumber - 1, content.trim());
				} else {
					int additionalItems = rowNumber - existingContentLines;
					while (additionalItems != 0) {
						if (additionalItems == 1) {
							readFileInList.add(rowNumber - 1, content.trim());
						} else {
							readFileInList.add(Constants.EMPTY);
						}
						additionalItems--;
					}
				}
				System.out.println("Inserted at line#" + rowNumber);
				continue;
			} else if (command.equalsIgnoreCase(Commands.SAVE.label)) {
				OutputFileWriter outputFileWriter = new OutputFileWriter();
				String filePath = outputFileWriter.writeToFile(readFileInList);
				System.out.println("File saved at " + filePath);
				continue;
			} else {
				System.out.println(
						"Kindly enter a valid command. Following are the supported commands\n1. list\n2. ins <row number> [content to insert]\n3. del <row number>\n4. save\n5. quit\n\n<> represents the required params\n[] represents optional params");
				continue;
			}
		}

	}

	private String readInputFileContent() {
		StringBuffer stringBuffer = new StringBuffer();
		int count = 0;
		for (String lineData : readFileInList) {
			stringBuffer.append(++count);
			stringBuffer.append(Constants.COLON);
			stringBuffer.append(lineData);
			stringBuffer.append(Constants.NEXT_LINE_CHAR);
		}
		return stringBuffer.toString();
	}
}



/**
 * This class holds the constants used in this application
 * 
 * @author SangameshVi
 *
 */
class Constants {

	/**
	 * Constant for next line
	 */
	public final static String NEXT_LINE_CHAR = "\n";

	/**
	 * Constant for user.home key of system property
	 */
	public final static String USER_HOME_KEY = "user.home";

	/**
	 * Constant for output file name
	 */
	public final static String OUTPUT_FILE_NAME = "OutputFile";

	/**
	 * Constant for text file extension of the output file
	 */
	public final static String OUTPUT_FILE_EXTENSION = ".txt";

	/**
	 * Constant for space string
	 */
	public final static String SPACE = " ";

	/**
	 * Constant for Empty string
	 */
	public final static String EMPTY = "";

	/**
	 * Constant for colon
	 */
	public final static String COLON = ":";

	/**
	 * Constant for number of input parameters allowed
	 */
	public final static int INPUT_PARAMS = 1;

	/**
	 * Constant for max number of input parameters supported for INSERT command
	 */
	public final static int INPUT_PARAMS_FOR_INSERT_CMD = 3;

	/**
	 * Constant for minimim number of parameters required for DELETE and INSERT
	 * commands
	 */
	public final static int DEF_INPUT_PARAMS_FOR_INSERT_CMD = 2;
}



/**
 * This class is the entry point for the JVM to start executing the application
 * 
 * @author SangameshVi
 *
 */
public class ExecutionHandler {

	/**
	 * This main method is the function that is being called by the JVM
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length < Constants.INPUT_PARAMS) {
			System.out.println("Kindly mention the input file path");
			System.exit(0);
		} else if (args.length > Constants.INPUT_PARAMS) {
			System.out.println("Program accepts only one input parameter");
			System.exit(0);
		}

		String inputFilePath = args[0];
		List<String> readFileInList = null;
		try {
			readFileInList = new InputFileReader(inputFilePath).readInputFile();
		} catch (FileNotFoundException e) {
			System.out.println("The given input file doesn't exist. Kindly run the application with a valid file path.");
			System.exit(0);
		}

		System.out.println(
				"Kindly enter a valid command. Following are the supported commands\n1. list\n2. ins <row number> [content to insert]\n3. del <row number>\n4. save\n5. quit\n\n<> represents the required params\n[] represents optional params");

		if (null != readFileInList) {
			CommandsExecutor commandsExecutor = new CommandsExecutor(readFileInList);
			commandsExecutor.executeCommand();
		}
	}

}



/**
 * This class is responsible for reading the input file and storing the read
 * data to a collection
 * 
 * @author SangameshVi
 *
 */
class InputFileReader {

	private String filePath;

	/**
	 * Constructor
	 * 
	 * @param inputFilePath Input File path
	 * @throws FileNotFoundException 
	 */
	public InputFileReader(final String inputFilePath) throws FileNotFoundException {
		File inputFile = new File(inputFilePath);
		if (!inputFile.exists()) {
			throw new FileNotFoundException("input file doesn't exist");
		}
		this.filePath = inputFilePath;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> readInputFile() {
		List<String> lines = Collections.emptyList();
		try {
			lines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return lines;
	}
}



/**
 * @author SangameshVi
 *
 */
class OutputFileWriter {

	/**
	 * 
	 * @param readFileInList
	 * @param fileWriteCounter
	 * @return
	 */
	public String writeToFile(List<String> readFileInList) {
		String userHome = System.getProperty(Constants.USER_HOME_KEY);
		String filePath = userHome + File.separator + Constants.OUTPUT_FILE_NAME + Constants.OUTPUT_FILE_EXTENSION;
		StringBuffer buffer = new StringBuffer();
		for (String content : readFileInList) {
			buffer.append(content);
			buffer.append(Constants.NEXT_LINE_CHAR);
		}

		BufferedWriter bufferedWriter = null;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(new File(filePath)));
			bufferedWriter.write(buffer.toString());
		} catch (Exception expt) {
		} finally {
			try {
				bufferedWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return filePath;
	}

}
